#ifndef HEADER_H
#define HEADER_H

extern void print_mem(char *array, int size, int current_pointer);
extern void run_machine(char *array, int array_size, int *current_pointer,
                        char *input, int input_size);
#endif // HEADER_H
