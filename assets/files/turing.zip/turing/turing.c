/**
 * Author: Karthik S. Vedula
 * Thank you to this video for helping me so much on this:
 * https://www.youtube.com/watch?v=QO6nYR6dr8Y
 *
 * Note that for some reason I made halt not a state, but isntead an action
 * (like move left and right)
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "machine.h"

typedef struct state {
  int state_number; // just in id
  char mem_value;   // the value in current memory location that it must have
  int next_state;
  char write_value; // '0', '1', or '_'
  char move;        // move left = '<' and move right = '>'; 'H' for halt.
} state;

typedef struct instruction {
  char machine_instruction[3]; // last is null
  int next_state;
} instruction;

const int MAX_LINE_LENGTH = 100; // used for reading lines from the file
const int MAX_INPUT_LIMIT = 100; // used for user input

// doing a linear search because I don't know how to a hashmap in c yet...
void search(int curr_state_number, char curr_mem_value, state *state_list,
            int state_list_len, state *match) {
  for (int i = 0; i < state_list_len; i++) {
    state s = state_list[i];
    if (s.state_number == curr_state_number && s.mem_value == curr_mem_value) {
      match->state_number = s.state_number;
      match->mem_value = s.mem_value;
      match->next_state = s.next_state;
      match->write_value = s.write_value;
      match->move = s.move;
      return;
    }
  }

  // if couldn't find state, just exit.
  printf("Couldn't find state with state number %d and mem value of %c",
         curr_state_number, curr_mem_value);
  exit(1);
}

void state_info_to_instruction(int state_number, char state_mem_value,
                               state *state_list, int state_list_len,
                               instruction *res) {
  state match;
  search(state_number, state_mem_value, state_list, state_list_len, &match);

  res->next_state = match.next_state;
  res->machine_instruction[0] = match.write_value;
  res->machine_instruction[1] = match.move;
  res->machine_instruction[2] = '\0';
}

/* file format is as follows:
 * first line is number of states.
 * every line after that is a single string, where the
 * 1st character: state number
 * 2nd character: memory value of the state
 * 3rd character: next state number
 * 4th character: write value
 * 5th character: which way to move (or Halt)
 */
state *get_states_from_file(char *filename, int num_lines) {
  FILE *pfile = fopen(filename, "r");
  if (pfile == NULL) {
    printf("No file %s", filename);
    exit(1);
  }

  state *states = malloc(num_lines * sizeof(state));

  char buf[MAX_LINE_LENGTH];


  for (int count = 0; count < num_lines; count++) {
    if (fgets(buf, MAX_LINE_LENGTH, pfile) != NULL) {
      states[count].state_number = buf[0] - '0'; // convert char to integer
      states[count].mem_value = buf[1];
      states[count].next_state = buf[2] - '0';
      states[count].write_value = buf[3];
      states[count].move = buf[4];
    }
  }

  return states;
}

int get_file_len(char *filename) {
  FILE *pfile = fopen(filename, "r");
  if (pfile == NULL) {
    printf("No file %s", filename);
    exit(1);
  }

  int lines = 0;

  while (!feof(pfile)) {
    int ch = fgetc(pfile);
    if (ch == '\n') {
      lines++;
    }
  }

  return lines;
}

int main(int argc, char *argv[]) {
  const int num_states = get_file_len(argv[1]);
  state* states = get_states_from_file(argv[1], num_states);

  // Set up machine
  int machine_arr_size = 20;
  char *machine_array = malloc(machine_arr_size * sizeof(char));
  memset(machine_array, '_', machine_arr_size);

  // write initial memory
  if (argc >= 4) {
    for (int i = 0; i < strlen(argv[3]) && i < MAX_INPUT_LIMIT; i++) {
      machine_array[i] = argv[3][i];
    }
  }
  // initial state
  int curr_state_number = 0;
  int current_pointer = atoi(argv[2]);

  instruction ins;
  state_info_to_instruction(curr_state_number, machine_array[current_pointer],
                            states, num_states, &ins);

  while (true) { // doing this since even if halt, we want to write first
    run_machine(machine_array, machine_arr_size, &current_pointer,
                ins.machine_instruction, 2); // instruction length always 2

    if (ins.machine_instruction[1] == 'H') {
      break;
    }

    state_info_to_instruction(curr_state_number, machine_array[current_pointer],
                              states, num_states, &ins);

    curr_state_number = ins.next_state;
  }

  free(states);
  free(machine_array);

  return 0;
}
