/**
 * Author: Karthik S. Vedula
 */

#define DELAY 100

#include <stdbool.h>
#include <stdio.h>

#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif

void print_mem(char *array, int size, int current_pointer) {
  // print values
  printf("[ ");
  for (int i = 0; i < size; i++) {
    printf("%-4c | ", array[i]);
  }
  printf("]\n");

  // print indices beneath
  printf("  ");
  for (int i = 0; i < size; i++) {
    printf("%-4d | ", i);
  }
  printf("\n");

  // print arrow showing where current pointer is
  // arrow tip
  printf("  ");
  for (int i = 0; i < current_pointer; i++) {
    printf("%-4s   ", " ");
  }
  printf("%-4s", "_");
  // arrow stem
  printf("\n  ");
  for (int i = 0; i < current_pointer; i++) {
    printf("%-4s   ", " ");
  }

  printf("%-4s", "|");
  printf("\n  ");
  for (int i = 0; i < current_pointer; i++) {
    printf("%-4s   ", " ");
  }

  printf("%-4s", "|");
  printf("\n");
}

void delay_and_flush() {
// from
// https://stackoverflow.com/questions/14818084/what-is-the-proper-include-for-the-function-sleep
#ifdef _WIN32
  Sleep(DELAY);
#else
  usleep(DELAY * 1000);
#endif

  // clear screen
  printf("\e[1;1H\e[2J");
}

void run_machine(char *array, int array_size, int *current_pointer, char *input,
                 int input_size) {
  // print_mem(*array, array_size, *current_pointer);

  for (int i = 0; i < input_size; i++) {
    if (*current_pointer < 0) {
      printf("Current pointer negative: %d\n", *current_pointer);
      return;
    }

    switch (input[i]) {
    case '>':
      (*current_pointer)++;
      break;
    case '<':
      (*current_pointer)--;
      break;
    case '0':
      array[*current_pointer] = '0';
      break;
    case '1':
      array[*current_pointer] = '1';
      break;
    case '_':
      array[*current_pointer] = '_';
      break;
    case 'H': // halt
      printf("\n\n--------------- HALTING -------------\n\n");
      print_mem(array, array_size, *current_pointer);
      return;
      break;

    case '\0': // empty, so do not print anything
    case ' ':
    case '\t':
    case '\n':
      continue;
    }

    printf("\n\n--------------- %c -------------\n\n", input[i]);
    print_mem(array, array_size, *current_pointer);
    delay_and_flush();
  }
}
